


# Introduction

This book contains a collection of vignettes that guide users through different ways to access data on the AnVIL platform. 

## Motivation

One of the most common questions people have when they switch to using the AnVIL platform is "how do I get data onto it?" We created this book to provide small, step-by-step examples for users to try so that they can feel confident finding or moving data onto AnVIL. Each vignette is quick and designed to take ~15 minutes.

It can be very exciting to learn how much data is at your fingertips! Once you have settled on some data to use, you'll want to bring it into AnVIL if it's not already there.

Navigate to the menu on the left to get started!

## Target Audience  

The course is intended for new and experienced users of the AnVIL platform. In order to follow the vignettes, **you must have an AnVIL account that is connected to a billing project.** Each vignette will incur only minimal costs.

If you don't have an AnVIL account yet, instructions on getting one can be found at the [AnVIL Portal](https://anvilproject.org/learn/get-started).

::: {.notice}
These vignettes are built around common tasks that an individual user might do. If you are bringing a large amount of data to AnVIL through a consortium, you might find [documentation for Data Submitters](https://anvilproject.org/learn/submit-data) more helpful.
:::

## Curriculum  

These vignettes cover the following topics:

**Bringing your own data to AnVIL** 

* Uploading data from your local computer 
* Uploading data from the cloud
* Uploading data from a high performance computing cluster

**Getting data from external data repositories** 

* Importing data from SRA
* Importing data from dbGaP

**Finding data stored on AnVIL** 

* Accessing open access data stored on AnVIL
* Accessing controlled access data stored on AnVIL using DUOS 
